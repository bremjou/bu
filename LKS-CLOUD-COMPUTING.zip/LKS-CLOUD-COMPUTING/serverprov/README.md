\# Techno Serverless OMS



\## Project Structure



```

Serverprov/

├── lambda/                     ← Lambda function source code (reference)

│   ├── order\_management/

│   │   ├── lambda\_function.py

│   │   └── README.md           ← Environment variables \& usage

│   ├── process\_payment/

│   ├── update\_inventory/

│   ├── send\_notification/

│   ├── generate\_report/

│   ├── init\_db/

│   ├── health\_check/

│   └── requirements.txt

├── frontend/

│   └── index.html              ← Dashboard frontend

├── codedeploy/

│   └── appspec.yml

├── .github/workflows/

│   └── deploy.yml              ← GitHub Actions CI/CD pipeline

└── amplify.yml

```



\## What Students Must Build



| Component | Notes |

|-----------|-------|

| CloudFormation (7 stacks) | Build from scratch via AWS Console |

| Step Functions ASL | Build from scratch via Workflow Studio |

| Lambda Layer | Build and upload manually |

| Upload Lambda code | Upload to each function after stack deployment |



\---





\## Test the API



```bash

API\_URL="https://YOUR\_API\_ID.execute-api.us-east-1.amazonaws.com/production"

API\_KEY="YOUR\_API\_KEY"



\# Health check

curl -s -H "x-api-key: $API\_KEY" "$API\_URL/health" | python3 -m json.tool



\# Create an order

curl -s -X POST "$API\_URL/orders" \\

&#x20; -H "x-api-key: $API\_KEY" \\

&#x20; -H "Content-Type: application/json" \\

&#x20; -d '{"customerId":"CUST001","items":\[{"productId":"PROD001","quantity":2}],"totalAmount":50000}' \\

&#x20; | python3 -m json.tool

```



\## Setup CI/CD (GitHub Actions)



Add secrets in your GitHub repository:



| Secret | Value |

|--------|-------|

| `AWS\_ACCESS\_KEY\_ID` | From Learner Lab |

| `AWS\_SECRET\_ACCESS\_KEY` | From Learner Lab |

| `AWS\_SESSION\_TOKEN` | From Learner Lab |

| `SNS\_TOPIC\_ARN` | SNS Topic ARN |

| `S3\_DEPLOYMENT\_BUCKET` | Logs bucket name |

| `AMPLIFY\_APP\_ID` | Amplify App ID (format: `dXXXXXXXX`) |



\---



\## Lambda Function Reference



| Function | Purpose | README |

|----------|---------|--------|

| `order\_management` | Order CRUD, validation, DB queries | \[README](lambda/order\_management/README.md) |

| `process\_payment` | Payment processing | \[README](lambda/process\_payment/README.md) |

| `update\_inventory` | Update product stock | \[README](lambda/update\_inventory/README.md) |

| `send\_notification` | Send email via SNS | \[README](lambda/send\_notification/README.md) |

| `generate\_report` | Generate reports to S3 | \[README](lambda/generate\_report/README.md) |

| `init\_db` | Initialize tables and sample data | \[README](lambda/init\_db/README.md) |

| `health\_check` | Check health of all services | \[README](lambda/health\_check/README.md) |



\---

