\# process\_payment



Simulates payment processing with idempotency support via DynamoDB.



\## Environment Variables



| Variable | Required | Description | Example |

|----------|----------|-------------|---------|

| `SECRET\_ARN` | Yes | ARN of the Secrets Manager secret containing RDS credentials | `arn:aws:secretsmanager:us-east-1:123456789:secret:techno-rds-secret` |

| `IDEMPOTENCY\_TABLE` | No | DynamoDB table name for idempotency checks. Defaults to `techno-payment-idempotency` | `techno-payment-idempotency` |



\## Input (from Step Functions)



```json

{

&#x20; "orderId": "ORD-001",

&#x20; "customerId": "CUST001",

&#x20; "totalAmount": 150000,

&#x20; "items": \[...]

}

```



\## Output



```json

{

&#x20; "paymentResult": {

&#x20;   "paymentStatus": "success",

&#x20;   "transactionId": "TXN-xxxxxxxx",

&#x20;   "amount": 150000

&#x20; }

}

```



The `paymentResult.paymentStatus` field is used by the Step Functions `PaymentChoice` state. Valid values: `success`, `failed`.



\## IAM Permissions Required



\- `secretsmanager:GetSecretValue`

\- `dynamodb:GetItem`

\- `dynamodb:PutItem`

