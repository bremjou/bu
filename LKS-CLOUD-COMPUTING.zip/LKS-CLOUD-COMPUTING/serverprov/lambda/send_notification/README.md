\# send\_notification



Sends order confirmation or failure notification emails via Amazon SNS.



\## Environment Variables



| Variable | Required | Description | Example |

|----------|----------|-------------|---------|

| `SNS\_TOPIC\_ARN` | Yes | ARN of the SNS topic used to send email notifications | `arn:aws:sns:us-east-1:123456789:techno-sns-topic` |



\## Input (from Step Functions)



```json

{

&#x20; "orderId": "ORD-001",

&#x20; "customerId": "CUST001",

&#x20; "totalAmount": 150000,

&#x20; "paymentResult": { "paymentStatus": "success" }

}

```



\## Output



```json

{

&#x20; "notificationResult": {

&#x20;   "notificationStatus": "sent",

&#x20;   "messageId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"

&#x20; }

}

```



\## IAM Permissions Required



\- `sns:Publish`

