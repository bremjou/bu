\# init\_db



Initializes the PostgreSQL database schema and optionally inserts sample data.



\## Environment Variables



| Variable | Required | Description | Example |

|----------|----------|-------------|---------|

| `SECRET\_ARN` | Yes | ARN of the Secrets Manager secret containing RDS credentials | `arn:aws:secretsmanager:us-east-1:123456789:secret:techno-rds-secret` |



\## Invocation



Invoke manually after the RDS instance is ready:



```bash

aws lambda invoke \\

&#x20; --function-name techno-lambda-init-db \\

&#x20; --payload '{"insert\_sample\_data": true}' \\

&#x20; --cli-binary-format raw-in-base64-out \\

&#x20; --region us-east-1 \\

&#x20; /tmp/result.json \&\& cat /tmp/result.json

```



Set `insert\_sample\_data` to `false` to create tables only without inserting data.



\## Tables Created



\- `customers` — customer profiles

\- `products` — product catalog with stock quantities

\- `orders` — order records linked to customers

\- `order\_items` — line items per order



\## IAM Permissions Required



\- `secretsmanager:GetSecretValue`

