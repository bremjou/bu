\# update\_inventory



Decrements product stock quantities after a successful payment.



\## Environment Variables



| Variable | Required | Description | Example |

|----------|----------|-------------|---------|

| `SECRET\_ARN` | Yes | ARN of the Secrets Manager secret containing RDS credentials | `arn:aws:secretsmanager:us-east-1:123456789:secret:techno-rds-secret` |

| `LOW\_STOCK\_THRESHOLD` | No | Quantity threshold below which a product is considered low stock. Defaults to `5` | `5` |



\## Input (from Step Functions)



```json

{

&#x20; "orderId": "ORD-001",

&#x20; "items": \[

&#x20;   { "productId": "PROD001", "quantity": 2 }

&#x20; ]

}

```



\## Output



```json

{

&#x20; "inventoryResult": {

&#x20;   "inventoryStatus": "updated",

&#x20;   "updatedProducts": \["PROD001"],

&#x20;   "lowStockProducts": \[]

&#x20; }

}

```



The `inventoryResult.inventoryStatus` field is used by the Step Functions `InventoryChoice` state. Valid values: `updated`, `failed`, `skipped`.



\## IAM Permissions Required



\- `secretsmanager:GetSecretValue`

